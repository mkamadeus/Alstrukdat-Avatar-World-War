#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>
#include "game.h"

#endif