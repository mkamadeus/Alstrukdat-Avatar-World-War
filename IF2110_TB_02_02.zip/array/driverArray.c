#include <stdio.h>
#include "array.h"

int main(){
    
    return 0;
}